# GEOSTAR

Application Android de géomancie traditionnelle ouest-africaine.
Génération de thèmes, navigation des 16 figures, solutions précalculées, favoris, table des correspondances (noms africains, occidentaux, allemands).

## Compilation automatique

Chaque push sur la branche `main` déclenche automatiquement la compilation de l'APK Android via GitHub Actions.

### Pour récupérer l'APK après un build

1. Va dans l'onglet **Actions** de ton dépôt GitHub
2. Clique sur le dernier workflow réussi (coche verte)
3. En bas de la page, dans **Artifacts**, télécharge `geostar-apk-debug.zip`
4. Décompresse-le : tu obtiens un fichier `geostar-12.25-arm64-v8a_armeabi-v7a-debug.apk`
5. Transfère ce fichier sur ton téléphone et installe-le (autorise l'installation de sources inconnues si demandé)

### Pour relancer un build manuellement

1. Onglet **Actions** → workflow **Build GEOSTAR Android APK**
2. Bouton **Run workflow** (à droite) → **Run workflow**

## Structure du projet

```
geostar-android/
├── main.py                       # Code principal Kivy
├── buildozer.spec                # Configuration de compilation Android
├── .github/
│   └── workflows/
│       └── build-android.yml     # Pipeline GitHub Actions
├── .gitignore
└── README.md
```

## Dépendances

- Python 3.10
- Kivy 2.3.0
- Pillow (manipulation d'images)
- pyjnius + android (accès aux APIs Android natives)

## Test en local (PC, sans Android)

```bash
pip install kivy==2.3.0 pillow
python main.py
```

## Notes importantes

- **Premier build : 60 à 90 minutes** (téléchargement du NDK Android, compilation de Python pour Android, etc.). Les builds suivants sont beaucoup plus rapides grâce au cache.
- **APK debug** : signé avec une clé de test, suffisant pour installation personnelle. Pour publication sur le Play Store il faudra produire un AAB release signé séparément.
- **Permissions demandées** : Internet, lecture/écriture stockage, micro, vibration.
